---
name: The Architect
colors:
  surface: '#fcf9f4'
  surface-dim: '#dcdad5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ee'
  surface-container: '#f1ede8'
  surface-container-high: '#ebe8e3'
  surface-container-highest: '#e5e2dd'
  on-surface: '#1c1c19'
  on-surface-variant: '#444748'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f3f0eb'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5e5e5c'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdc'
  on-secondary-container: '#636360'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c1b1a'
  on-tertiary-container: '#868382'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#e4e2de'
  secondary-fixed-dim: '#c8c6c3'
  on-secondary-fixed: '#1b1c1a'
  on-secondary-fixed-variant: '#474744'
  tertiary-fixed: '#e6e2df'
  tertiary-fixed-dim: '#cac6c4'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#fcf9f4'
  on-background: '#1c1c19'
  surface-variant: '#e5e2dd'
typography:
  h1:
    fontFamily: Newsreader
    fontSize: 4rem
    fontWeight: '400'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontFamily: Newsreader
    fontSize: 2.5rem
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h3:
    fontFamily: Newsreader
    fontSize: 1.75rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: '0'
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.7'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  code:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-caps:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
spacing:
  unit: 4px
  xs: 0.5rem
  sm: 1rem
  md: 2rem
  lg: 4rem
  xl: 8rem
  gutter: 1.5rem
  container_max: 1120px
---

## Brand & Style

This design system is built on the principles of **Architectural Minimalism**. It treats the digital screen as a physical gallery space—prioritizing structural integrity, deliberate negative space, and a rhythmic cadence of content. The brand personality is academic yet modern, suggesting a developer who approaches code with the precision of a master craftsman and the intellectual depth of a researcher.

The visual language avoids trends in favor of timelessness. It utilizes high-contrast tonal shifts and a rigid adherence to a structural grid to convey expertise and reliability. The emotional response is one of calm authority; the interface recedes to ensure the developer's work and thoughts remain the primary focus.

## Colors

The palette is strictly limited to maintain a high-end, editorial feel. 

- **Primary Background (#FDFBF7):** A warm, cream white that reduces eye strain compared to pure white and evokes the texture of high-quality paper.
- **Ink Black (#1A1A1A):** Used for typography and structural elements to provide a grounded, definitive weight.
- **Muted Neutrals:** Soft greys and "dusty" versions of the cream base are used exclusively for subtle borders and secondary information.

Color should never be used for decoration. It is reserved for functional signaling (e.g., syntax highlighting in code blocks) or to draw focus to specific call-to-actions.

## Typography

Typography is the primary vehicle for the design system's identity. 

- **Newsreader** is employed for all headlines. Its italic variant should be used sparingly for emphasis or to denote publication titles, enhancing the academic aesthetic.
- **Inter** provides a functional contrast. It is utilized for body copy, navigation, and code snippets. Despite being a sans-serif, its high x-height maintains the readability required for dense technical documentation.
- **Hierarchy:** Large margins and exaggerated scale differences between headlines and body text create a clear path for the reader's eye.

## Layout & Spacing

The layout follows a **Fixed Grid System** centered on the screen, mimicking the margins of a printed book or a blueprint.

- **Grid:** A 12-column grid with a 1120px max-width.
- **Rhythm:** A vertical rhythm based on an 8px baseline. Large sections are separated by `xl` (128px) spacing to allow the content to breathe.
- **Margins:** Generous outer margins are mandatory. Content should never feel crowded against the viewport edges.
- **Alignment:** Strict left-alignment for all text blocks to maintain a clean vertical axis.

## Elevation & Depth

This design system rejects shadows in favor of **Tonal Layers** and **Low-Contrast Outlines**.

Depth is achieved through:
1.  **Framing:** Using 1px solid borders in the neutral tint (#E5E2DD) to box sections or images.
2.  **Layering:** Elements do not "float" above the surface; they sit "on" the surface. Interactive states are indicated by shifts in background color (e.g., from Cream to a slightly darker shade) rather than an increase in elevation or shadow.
3.  **Rule Lines:** Horizontal and vertical 1px lines are used to separate content hierarchies, reinforcing the architectural feel.

## Shapes

The shape language is **Sharp (0)**. 

To maintain the professional and academic tone, no rounded corners are permitted. Every button, input field, and image container must have 90-degree angles. This rigor emphasizes the "precise" and "expert" brand personality, aligning with technical schematics and traditional editorial layouts.

## Components

### Buttons
Primary buttons are solid Ink Black (#1A1A1A) with Cream text. Secondary buttons are transparent with a 1px Black border. Hover states should simply invert the colors (Black becomes Cream, Cream becomes Black) with a 0.2s transition.

### Chips & Tags
Small, 1px bordered rectangles using the `label-caps` typography style. They should have generous horizontal padding (12px) to maintain a clean look.

### Input Fields
Minimalist 1px bottom-border only. On focus, the border-bottom thickens to 2px. Labels should use the `label-caps` style and sit above the field.

### Cards
Cards are defined not by shadows, but by a 1px border or a subtle background fill. They should have a consistent padding of `md` (32px).

### Code Blocks
Code blocks should use a slightly darker background (#F5F2ED) to distinguish them from the primary page color. Syntax highlighting should use a muted, professional palette—avoiding neon colors in favor of deep blues, ochres, and sage greens.

### Additional Components
- **Section Dividers:** 1px horizontal lines spanning the full container width with the section title sitting just above the line in `label-caps`.
- **Breadcrumbs:** Simple text strings separated by a forward slash (/), prioritizing utility and clear site architecture.